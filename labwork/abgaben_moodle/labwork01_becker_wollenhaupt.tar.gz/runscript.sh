#!/bin/bash

./main.py https://dhbw.johannes-bauer.com/lwsub 05d88ca5-7fa0-4a2f-8472-123e0f5aa3de labwork01